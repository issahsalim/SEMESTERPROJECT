#include<iostream>
using namespace std;
int main(){
	int chioce;
	string user,pass,user1,pass1;
	do{
	
	cout<<"\n\t\t******************\n";	
	cout<<"\t\t\tMENU\n";
	cout<<"\t\t******************\n\n";
	 begain:
	cout<<"\n\t\t 1.Add user\n";
	cout<<"\t\t 2.Login\n";
	cout<<"\t\t 3.Exit\n";
	cout<<"\t\t Select option: ";
	cin>>chioce;
	 
	 // CHECKING IF USER ENTER'S A STRING
	 if(cin.fail()){
	 	cout<<"\t\tAccept Only numbers!";
	     return 0;
 	 }
 	 
 	 // CHECKING FOR INVALID INPUT
 	 else if(chioce>3){
 	 	cout<<"\t\tInvalid Option Choosed.Try again\n";
 	 	goto begain;
	  }
	 switch(chioce){
	 	case 1:
	 		{
			 // ADDING A USER
	 		 restart:
	 		cout<<" \t\tEnter Username: ";
	 		cin>>user;
	 		cout<<" \t\tEnter Password: ";
	 		cin>>pass;
	 		 system("cls");
	 		cout<<"\t\tUser added successfully!\n";
	 		 system("pause");
	 		 goto begain;
	 		 break;
	 	}
	 	case 2:
	 		{
			 // LOGINING IN USER ACCOUT
	 		 user:
			cout<<"\t\tEnter Your username: ";
			cin>>user1;
			pass:
			cout<<"\t\tEnter your password: ";
			 cin>>pass1;
			
 	 			// CHECKING IF PASSWORD AND USERNAME IS CORRECT
			 if(user1==user && pass1==pass){
 			 	cout<<" \t\tLogin as "<<user;
			 	return 0;
			 }
			  // CHECKING IF PASSWORD IS NOT CORRECT
			 else if(user1==user && pass1!=pass){
			 	cout<<" \t\tIncorrect password.try gain\n";
			 	goto pass;
			 }
			 // CHECKING IF USERNAME IS NOT CORRECT
			 else if(user1!=user && pass1==pass){
			 	cout<<"\t\t User name can't be found.Try again\n";
			 	 goto user;
			 }
	 	
	 		break;
	 	}
	 	 
	 }	 
} while( chioce!=3);
 cout<<"\n\t\tTHANK YOU!";
return 0; 

 }
